import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ConfirmDialogComponent } from './confirm-dialog/confirm-dialog.component';

@Component({
  selector: 'app-root',
  templateUrl:'./app.component.html',
  styleUrls: ['./app.component.scss']  
})
export class AppComponent {
  title = 'demoapp';
  data  = [
    {id:1, name: 'T. Rathinasamy', dob: '20.02.1961', Work: ' Mechanic', Qulification: 'IIT'},
    {id:2, name: 'R. Packiyalakshmi', dob: '20.5.1964', Work: 'Beediroller', Qulification: '8th'},
    {id:3, name: 'R. Thiyagu', dob: '04.11.1988', Work: 'Supervisor', Qulification: 'DECE'},
    {id:4, name: 'R. Anbarasi', dob: '18.07.1993', Work: 'Developer', Qulification: 'BTech'},
    {id:5, name: 'R. Inbarasi', dob: '06.04.1997', Work: 'Developer', Qulification: 'DIT'}, 
  ];
  students$ :any = this.http.get('http://localhost:3000/students');
  displayedColumns = ['id', 'name', 'dob', 'work', 'qulification', 'edit'];
  displayedColumnsnew = ['name', 'standard', 'subject', 'mark','id'];
  constructor(public dialog: MatDialog, public http : HttpClient){
  }
  deleteDetail(element:any){
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {

    })
    dialogRef.afterClosed().subscribe(result => {
      if(result)
      this.data = this.data.filter(item => item.id !== element.id);
    });
    
  }
}


class AppModule {}

